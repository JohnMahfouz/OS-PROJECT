// User-level Semaphore
#include "inc/lib.h"

struct semaphore create_semaphore(char *semaphoreName, uint32 value)
{
	//TODO: [PROJECT'24.MS3 - #02] [2] USER-LEVEL SEMAPHORE - create_semaphore
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("create_semaphore is not implemented yet");
	//Your Code is Here...
	struct semaphore jo_semaph;
	struct __semdata* jo_semdata= smalloc(semaphoreName,sizeof(struct __semdata),1);
	strcpy(jo_semdata->name,semaphoreName);
	jo_semdata->count=value;
	jo_semdata->lock=0;
	sys_init_queue(&(jo_semdata->queue));
	jo_semaph.semdata=jo_semdata;
	return jo_semaph;


}
struct semaphore get_semaphore(int32 ownerEnvID, char* semaphoreName)
{
	//TODO: [PROJECT'24.MS3 - #03] [2] USER-LEVEL SEMAPHORE - get_semaphore
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("get_semaphore is not implemented yet");
	//Your Code is Here...
	struct __semdata* jo_semdata= (struct __semdata* )sget(ownerEnvID,semaphoreName);
	struct semaphore jo_semaph;
	jo_semaph.semdata=jo_semdata;
	return jo_semaph;
}

void wait_semaphore(struct semaphore sem)
{
	//TODO: [PROJECT'24.MS3 - #04] [2] USER-LEVEL SEMAPHORE - wait_semaphore
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("wait_semaphore is not implemented yet");
	//Your Code is Here...

//	sys_acquire_qlock();
	while(xchg(&(sem.semdata->lock),1) != 0);
	sem.semdata->count--;
	if(sem.semdata->count<0)
	{
		sys_semaph_wait(&sem.semdata->queue,&(sem.semdata->lock));
	}
	sem.semdata->lock=0;
}

void signal_semaphore(struct semaphore sem)
{
	//TODO: [PROJECT'24.MS3 - #05] [2] USER-LEVEL SEMAPHORE - signal_semaphore
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("signal_semaphore is not implemented yet");
	//Your Code is Here...
	while(xchg(&(sem.semdata->lock),1) != 0);
	sem.semdata->count++;
	if(sem.semdata->count<=0)
	{
		sys_semaph_signal(&sem.semdata->queue);
	}
	sem.semdata->lock=0;
}



int semaphore_count(struct semaphore sem)
{
	return sem.semdata->count;
}
