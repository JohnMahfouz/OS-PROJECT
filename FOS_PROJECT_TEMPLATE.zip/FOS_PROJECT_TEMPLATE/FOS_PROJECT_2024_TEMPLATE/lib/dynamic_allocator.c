/*
 * dynamic_allocator.c
 *
 *  Created on: Sep 21, 2023
 *      Author: HP
 */
#include <inc/assert.h>
#include <inc/string.h>
#include "../inc/dynamic_allocator.h"


//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//

//=====================================================
// 1) GET BLOCK SIZE (including size of its meta data):
//=====================================================
__inline__ uint32 get_block_size(void* va)
{
	uint32 *curBlkMetaData = ((uint32 *)va - 1) ;
	return (*curBlkMetaData) & ~(0x1);
}

//===========================
// 2) GET BLOCK STATUS:
//===========================
__inline__ int8 is_free_block(void* va)
{
	uint32 *curBlkMetaData = ((uint32 *)va - 1) ;
	return (~(*curBlkMetaData) & 0x1) ;
}

//===========================
// 3) ALLOCATE BLOCK:
//===========================

void *alloc_block(uint32 size, int ALLOC_STRATEGY)
{
	void *va = NULL;
	switch (ALLOC_STRATEGY)
	{
	case DA_FF:
		va = alloc_block_FF(size);
		break;
	case DA_NF:
		va = alloc_block_NF(size);
		break;
	case DA_BF:
		va = alloc_block_BF(size);
		break;
	case DA_WF:
		va = alloc_block_WF(size);
		break;
	default:
		cprintf("Invalid allocation strategy\n");
		break;
	}
	return va;
}

//===========================
// 4) PRINT BLOCKS LIST:
//===========================

void print_blocks_list(struct MemBlock_LIST list)
{
	cprintf("=========================================\n");
	struct BlockElement* blk ;
	cprintf("\nDynAlloc Blocks List:\n");
	LIST_FOREACH(blk, &list)
	{
		cprintf("(size: %d, isFree: %d)\n", get_block_size(blk), is_free_block(blk)) ;
	}
	cprintf("=========================================\n");

}
//
////********************************************************************************//
////********************************************************************************//

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

bool is_initialized = 0;
//==================================
// [1] INITIALIZE DYNAMIC ALLOCATOR:
//==================================
void initialize_dynamic_allocator(uint32 daStart, uint32 initSizeOfAllocatedSpace)
{
	//==================================================================================
	//DON'T CHANGE THESE LINES==========================================================
	//==================================================================================
	{
		if (initSizeOfAllocatedSpace % 2 != 0) initSizeOfAllocatedSpace++; //ensure it's multiple of 2
		if (initSizeOfAllocatedSpace == 0)
			return ;
		is_initialized = 1;
	}
	//==================================================================================
	//==================================================================================

	//TODO: [PROJECT'24.MS1 - #04] [3] DYNAMIC ALLOCATOR - initialize_dynamic_allocator
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("initialize_dynamic_allocator is not implemented yet");
	//Your Code is Here...
	LIST_INIT(&freeBlocksList);
		uint32 *daBeg=(uint32*)(daStart);
		*daBeg=1;
		uint32 *daEnd= (uint32*)(daStart +initSizeOfAllocatedSpace- sizeof(int)) ;
		*daEnd=1;
		uint32 *blkHeader=(uint32*)(daStart + sizeof(int));
			*blkHeader = initSizeOfAllocatedSpace- 2*sizeof(int);
		uint32 *blkFooter=(uint32*)(daStart +  initSizeOfAllocatedSpace - 2*sizeof(int));
		*blkFooter = initSizeOfAllocatedSpace- 2*sizeof(int);
		struct BlockElement* block=(struct BlockElement*)(daStart+ 2*sizeof(int));
	    LIST_INSERT_HEAD(&freeBlocksList,block);
		//set_block_data(block,initSizeOfAllocatedSpace-2*sizeof(int),0);
		//print_blocks_list(freeBlocksList);

}
//==================================
// [2] SET BLOCK HEADER & FOOTER:
//==================================
void set_block_data(void* va, uint32 totalSize, bool isAllocated)
{
	//TODO: [PROJECT'24.MS1 - #05] [3] DYNAMIC ALLOCATOR - set_block_data
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("set_block_data is not implemented yet");
	//Your Code is Here...
	uint32* blkheader= (uint32 *)((uint32)va - sizeof(int));
	*blkheader =(isAllocated | totalSize);
	uint32* blkfooter= (uint32 *)((uint32)va + (totalSize-(2*sizeof(int))));
	*blkfooter =(isAllocated | totalSize);
}


//=========================================
// [3] ALLOCATE BLOCK BY FIRST FIT:
//=========================================
void *alloc_block_FF(uint32 size)
{
	//==================================================================================
	//DON'T CHANGE THESE LINES==========================================================
	//==================================================================================
	{
		if (size % 2 != 0) size++;	//ensure that the size is even (to use LSB as allocation flag)
		if (size < DYN_ALLOC_MIN_BLOCK_SIZE)
			size = DYN_ALLOC_MIN_BLOCK_SIZE ;
		if (!is_initialized)
		{
			uint32 required_size = size + 2*sizeof(int) /*header & footer*/ + 2*sizeof(int) /*da begin & end*/ ;
			uint32 da_start = (uint32)sbrk(ROUNDUP(required_size, PAGE_SIZE)/PAGE_SIZE);
			uint32 da_break = (uint32)sbrk(0);
			initialize_dynamic_allocator(da_start, da_break - da_start);
		}
	}
	//==================================================================================
	//==================================================================================

	//TODO: [PROJECT'24.MS1 - #06] [3] DYNAMIC ALLOCATOR - alloc_block_FF
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("alloc_block_FF is not implemented yet");
	//Your Code is Here.8..
	struct BlockElement *Jo_blk;
	uint32 Jo_req_size = size + 2*sizeof(int);
	LIST_FOREACH(Jo_blk,&freeBlocksList){

		if(get_block_size(Jo_blk)>=Jo_req_size){

			if(get_block_size(Jo_blk)-Jo_req_size>=16){

				struct BlockElement *Next_Jo_blk2 = (struct BlockElement*)((uint32)Jo_blk+Jo_req_size);
				set_block_data(Next_Jo_blk2,get_block_size(Jo_blk)-Jo_req_size,0);
				set_block_data(Jo_blk,Jo_req_size,1);
				LIST_INSERT_AFTER(&freeBlocksList,Jo_blk,Next_Jo_blk2);
				LIST_REMOVE(&freeBlocksList,Jo_blk);

				return Jo_blk;
			}
			else{
				set_block_data(Jo_blk,get_block_size(Jo_blk),1);
				LIST_REMOVE(&freeBlocksList,Jo_blk);

				return Jo_blk;
			}
		}
	}
	uint32 addr = (uint32)sbrk(1);


	if(addr==-1){

		return NULL;
	}
	else
	{
		struct BlockElement *No_blk;

		set_block_data((uint32*)addr,PAGE_SIZE,1);

		uint32* END_BLOCK=(uint32*)(addr+PAGE_SIZE-sizeof(int));

		*END_BLOCK=1;

		free_block((void*)addr);

		return alloc_block_FF(size);


	}
	return NULL;
}


//=========================================
// [4] ALLOCATE BLOCK BY BEST FIT:
//=========================================
void *alloc_block_BF(uint32 size)
{
	{
			if (size % 2 != 0) size++;	//ensure that the size is even (to use LSB as allocation flag)
			if (size < DYN_ALLOC_MIN_BLOCK_SIZE)
				size = DYN_ALLOC_MIN_BLOCK_SIZE ;
			if (!is_initialized)
			{
				uint32 required_size = size + 2*sizeof(int) /*header & footer*/ + 2*sizeof(int) /*da begin & end*/ ;
				uint32 da_start = (uint32)sbrk(ROUNDUP(required_size, PAGE_SIZE)/PAGE_SIZE);
				uint32 da_break = (uint32)sbrk(0);
				initialize_dynamic_allocator(da_start, da_break - da_start);
			}
		}
	//TODO: [PROJECT'24.MS1 - BONUS] [3] DYNAMIC ALLOCATOR - alloc_block_BF
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("alloc_block_BF is not implemented yet");
	//Your Code is Here...

	uint32 minimum = 4294967295;
//	cprintf("%u\n",minimum);
	struct BlockElement *blk;
	struct BlockElement *blk2 = NULL;
	uint32 req_size = size + 2*sizeof(int);
//	cprintf("1\n");
	LIST_FOREACH(blk,&freeBlocksList){
		if(minimum==0)
		{
			 break;
		}
		if(get_block_size(blk)>=req_size)
		{
			if(minimum>=(get_block_size(blk)-req_size))
			{
//				cprintf("2\n");
//					cprintf("3\n");
				minimum=get_block_size(blk)-req_size;
				blk2=blk;

//				cprintf("4\n");

			}
		}
	}
		if(blk2==NULL)
		{
//			cprintf("6\n");
			return NULL;
		}
//uint32 blocksize =	get_block_size(blk2);
//cprintf("special%u\n",blocksize);

//		if(minimum==200000000)
//		{	cprintf("5\n");
//			return NULL;
//		}
	//(16*sizeof(char))
	if(get_block_size(blk2)-req_size>=16)
	{	struct BlockElement *blk3 = (struct BlockElement*)((uint32)blk2+req_size);
//		cprintf("7\n");
		set_block_data(blk3,(get_block_size(blk2)-req_size),0);
//		cprintf("8\n");
		set_block_data(blk2,req_size,1);
//		cprintf("9\n");
		LIST_INSERT_AFTER(&freeBlocksList,blk2,blk3);
//		cprintf("10\n");
		LIST_REMOVE(&freeBlocksList,blk2);
//		cprintf("11\n");
		return blk2;

	} 	//(16*sizeof(char))
	if(get_block_size(blk2)-req_size<16)
	{
//		cprintf("12\n");
		set_block_data(blk2,get_block_size(blk2),1);
//		cprintf("13\n");
		LIST_REMOVE(&freeBlocksList,blk2);
//		cprintf("14\n");
		return blk2;

	}
return NULL;
}

//===================================================
// [5] FREE BLOCK WITH COALESCING:
//===================================================
void free_block(void *va)
{
	//TODO: [PROJECT'24.MS1 - #07] [3] DYNAMIC ALLOCATOR - free_block
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("free_block is not implemented yet");
	//Your Code is Here...
	if(va==NULL)
	{
		return;
	}
	struct BlockElement *blk2 = (struct BlockElement*)((uint32)va);
	uint32 *blkfooter1 = (uint32*)((uint32)blk2-2*sizeof(int));
	uint32 *blkheader2 = (uint32*)((uint32)blk2-sizeof(int));
	uint32 sizeblk1 = *blkfooter1 & ~(0x1);
	struct BlockElement *blk1 = (struct BlockElement*)(uint32)((uint32)va-sizeblk1);
	struct BlockElement *blk3 = (struct BlockElement*)((uint32)((uint32)va+get_block_size(blk2)));

	if(!is_free_block(blk2)){

	//1st case both front and back
	if(is_free_block(blk3)&&is_free_block(blk1))
		{
		uint32 size = get_block_size(blk2)+get_block_size(blk3)+get_block_size(blk1);
		//set_block_data(blk3,0,0);
		//set_block_data(blk2,0,0);
		set_block_data(blk1,size,0);

		LIST_REMOVE(&freeBlocksList,blk3);

		}
	//2nd case only need back
	else if(is_free_block(blk1)&&!is_free_block(blk3))
		{
		uint32 size = get_block_size(blk2)+ get_block_size(blk1);
		//set_block_data(blk2,0,0);
		set_block_data(blk1,size,0);

		}
	//3rd case only front
	else if(!is_free_block(blk1)&&is_free_block(blk3))
			{
		uint32 size = get_block_size(blk2)+ get_block_size(blk3);
		set_block_data(blk2,size,0);
		//set_block_data(blk3,0,0);
		LIST_INSERT_BEFORE(&freeBlocksList,blk3,blk2);
		LIST_REMOVE(&freeBlocksList,blk3);
			}
	else{
		uint32 size = get_block_size(blk2);
		set_block_data(blk2,size,0);
		struct BlockElement *blk;
		struct BlockElement *blk3;
		LIST_FOREACH(blk,&freeBlocksList){
			if(blk>blk2){
				LIST_INSERT_BEFORE(&freeBlocksList,blk,blk2);
				return;
			}
		}
		LIST_INSERT_TAIL(&freeBlocksList,blk2);
	}


}
}

//=========================================
// [6] REALLOCATE BLOCK BY FIRST FIT:
//=========================================
void *realloc_block_FF(void* va, uint32 new_size)
{
	//TODO: [PROJECT'24.MS1 - #08] [3] DYNAMIC ALLOCATOR - realloc_block_FF
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("realloc_block_FF is not implemented yet");
	//Your Code is Here...
	struct BlockElement *blk = (struct BlockElement*)((uint32)va);
	uint32 Jo_new_size= new_size+2*sizeof(int);


	if(new_size==0 && va!= NULL){

		free_block(va);
		return NULL;
	}
	else if(va==NULL && new_size!=0){
	 va=alloc_block_FF(new_size);
	 return va;

	}
	else if(va==NULL && new_size==0){
		return NULL;
	}

	if(Jo_new_size==get_block_size(blk)) {
		return blk;
	}

	if(Jo_new_size < get_block_size(blk)){
		//cprintf("1\n");
		   if( get_block_size(blk)-Jo_new_size>=16){
			   struct BlockElement *nextBlk = (struct BlockElement*)((uint32)va+Jo_new_size);

			   set_block_data(nextBlk,get_block_size(blk)-Jo_new_size,1);
			   set_block_data(blk,Jo_new_size,1);

			   free_block(nextBlk);
	//		   LIST_INSERT_AFTER(&freeBlocksList,blk,nextBlk);
	//		   LIST_REMOVE(&freeBlocksList,blk);
			   //cprintf("2\n");
			   return blk;
		   }
		   else{
			   //cprintf("3\n");
			   return blk;
		   }
	   }


   if(Jo_new_size>get_block_size(blk)){
	  // cprintf("4\n");
	struct BlockElement *nextBlk= (struct BlockElement *)((uint32)va+get_block_size(blk));
		if(is_free_block(nextBlk)){
			if(get_block_size(blk)+get_block_size(nextBlk)>= Jo_new_size){
//				free_block(blk);

				if(get_block_size(blk)+get_block_size(nextBlk)-Jo_new_size>=16)
				{
			//	cprintf("5\n");
				struct BlockElement *splitBlk=(struct BlockElement*)((uint32)blk+Jo_new_size);
				//cprintf("5.1\n");
				set_block_data(splitBlk,(get_block_size(blk)+get_block_size(nextBlk))-Jo_new_size,1);
				free_block(splitBlk);
				//cprintf("5.2\n");
				//feh haga na2sa hena
				set_block_data(blk,Jo_new_size,1);
			//	cprintf("5.3\n");

			//	cprintf("5.4\n");
				LIST_REMOVE(&freeBlocksList,nextBlk);
				//cprintf("5.5\n");
				return blk;
				}

				else{
				//	cprintf("6\n");
					set_block_data(blk,get_block_size(blk)+get_block_size(nextBlk),1);
					LIST_REMOVE(&freeBlocksList,nextBlk);
							return blk;
				}

			}
			else{
				//cprintf("7\n");
				va=alloc_block_FF(new_size);
				if(va==NULL){
					return blk;
				}
				memcpy(va,blk,get_block_size(blk));
				free_block(blk);
				return va;
			}

		}
		else{
			//cprintf("8\n");
			va=alloc_block_FF(new_size);
			if(va==NULL){
								return blk;
							}
			memcpy(va,blk,get_block_size(blk));
			free_block(blk);
			return va;

		}
	}




	return NULL;




// 3amlt case lw size>current b kol ehtmalat



return NULL;

}

/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
//=========================================
// [7] ALLOCATE BLOCK BY WORST FIT:
//=========================================
void *alloc_block_WF(uint32 size)
{
	panic("alloc_block_WF is not implemented yet");
	return NULL;
}

//=========================================
// [8] ALLOCATE BLOCK BY NEXT FIT:
//=========================================
void *alloc_block_NF(uint32 size)
{
	panic("alloc_block_NF is not implemented yet");
	return NULL;
}
