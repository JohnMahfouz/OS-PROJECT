#include <inc/lib.h>

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

//=============================================
// [1] CHANGE THE BREAK LIMIT OF THE USER HEAP:
//=============================================
int Nour[NUM_OF_UHEAP_PAGES];

/*2023*/
void* sbrk(int increment)
{
	return (void*) sys_sbrk(increment);
}

//=================================
// [2] ALLOCATE SPACE IN USER HEAP:
//=================================

void* malloc(uint32 size)
{
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	if (size == 0) return NULL ;

	uint32 allocate_size = ROUNDUP(size,PAGE_SIZE);
	uint32 Jo_pages=(ROUNDUP(size,PAGE_SIZE)/PAGE_SIZE);
	uint32 Temp=0;
	uint32 Jo_heapStart=(myEnv->Jo_user_hard_limit+PAGE_SIZE);
	uint32 firstPageVA=0;
	uint32 Jo_counter=0;
	uint32 Nour_max = (USER_HEAP_MAX - (myEnv->Jo_user_hard_limit + PAGE_SIZE)) / PAGE_SIZE;
	uint32 firstPageAddress=0;

		if(!sys_isUHeapPlacementStrategyFIRSTFIT())
		{
			return NULL;
		}


		if(size > DYN_ALLOC_MAX_BLOCK_SIZE)
		{
			uint32 Jo_sta = Jo_heapStart;

			for(uint32 i=0;i<Nour_max;i++)
			{
					if ( Nour[i]==1)
					{
						Jo_counter = 0;
					}
					else if (Nour[i]==0)
					{
						Jo_counter++;
					}
					if(Jo_counter == 1)
					{
						firstPageVA = i;
					}
					if(Jo_counter == Jo_pages)
					{
						break;
					}

			}
		  if(Jo_counter == Jo_pages)
		  {
	   firstPageAddress=(myEnv->Jo_user_hard_limit+PAGE_SIZE)+firstPageVA*PAGE_SIZE;
	  uint32 temp = firstPageAddress;
	  for (int i = firstPageVA; i < firstPageVA + Jo_pages; i++) {
	      if (i == firstPageVA) {
	          Nour[i] = Jo_pages;
	      } else {
	          Nour[i] = 1;
	      }
	  }
		sys_allocate_user_mem(firstPageAddress, allocate_size);
		  }
		  else
		  {
			  return NULL;
		  }

		}
		else if(size <= DYN_ALLOC_MAX_BLOCK_SIZE)
		{
			return alloc_block_FF(size);
		}

		return (void*)firstPageAddress;
}




//=================================
// [3] FREE SPACE FROM USER HEAP:
//=================================
void free(void* virtual_address)
{
	//TODO: [PROJECT'24.MS2 - #14] [3] USER HEAP [USER SIDE] - free()
	// Write your code here, remove the panic and write your code
	//panic("free() is not implemented yet...!!");
	uint32 Jo_va = (uint32)virtual_address;
	if((uint32)virtual_address >= (uint32)myEnv->Jo_user_hard_limit + PAGE_SIZE && (uint32)virtual_address < USER_HEAP_MAX)
	{
		uint32 Jo_counter = 0;
		uint32 index = (Jo_va-myEnv->Jo_user_hard_limit-PAGE_SIZE )/PAGE_SIZE;
		Jo_counter = Nour[index];
		uint32 Stop =index+Jo_counter;
		for(int i=index;i<Stop;i++)
				{
					Nour[i]=0;
				}


		sys_free_user_mem((uint32)Jo_va,Jo_counter);
	  }
	else if((uint32)virtual_address >= USER_HEAP_START && (uint32)virtual_address < (uint32)(myEnv->Jo_user_hard_limit))
	{
		free_block(virtual_address);
	}
	else
	{
		panic("Virtual address is not mapped");
	}
}

//=================================
// [4] ALLOCATE SHARED VARIABLE:
//=================================
void* smalloc(char *sharedVarName, uint32 size, uint8 isWritable)
{
		uint32 allocate_size = ROUNDUP(size,PAGE_SIZE);
		uint32 Jo_pages=(ROUNDUP(size,PAGE_SIZE)/PAGE_SIZE);
		uint32 Temp=0;
		uint32 Jo_heapStart=(myEnv->Jo_user_hard_limit+PAGE_SIZE);
		uint32 firstPageVA=0;
		uint32 Jo_counter=0;
		uint32 Nour_max = (USER_HEAP_MAX - (myEnv->Jo_user_hard_limit + PAGE_SIZE)) / PAGE_SIZE;
		uint32 firstPageAddress=0;
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	if (size == 0) return NULL ;
	//==============================================================
	//TODO: [PROJECT'24.MS2 - #18] [4] SHARED MEMORY [USER SIDE] - smalloc()
	// Write your code here, remove the panic and write your code
//	panic("smalloc() is not implemented yet...!!");

	if(!sys_isUHeapPlacementStrategyFIRSTFIT())
		{
			return NULL;
		}
		for(uint32 i=0 ;i<Nour_max; i++)
		{

			if( Nour[i]==0 )
			{
				Jo_counter++;
			}
			else
			{

				Jo_counter=0;
			}
				if(Jo_counter==1)
				{
					firstPageVA=i;
				}

				if(Jo_counter==Jo_pages)
				{
					uint32 firstPageAddress=(myEnv->Jo_user_hard_limit+PAGE_SIZE)+firstPageVA*PAGE_SIZE;
					for(int i=firstPageVA;i<firstPageVA+Jo_pages;i++)
					{
						if (i == firstPageVA) {
					Nour[i] = Jo_pages;
					} else {
					Nour[i] = 1;
					}
					}

					sys_allocate_user_mem(firstPageAddress,size);

					int choice = sys_createSharedObject(sharedVarName,size,isWritable,(void*)firstPageAddress);

					if(choice<0) {
						return NULL;
					}
					return (void *)firstPageAddress;
				}


		}
	return NULL;
	}



//========================================
// [5] SHARE ON ALLOCATED SHARED VARIABLE:
//========================================
void* sget(int32 ownerEnvID, char *sharedVarName)
{
	//TODO: [PROJECT'24.MS2 - #20] [4] SHARED MEMORY [USER SIDE] - sget()
	// Write your code here, remove the panic and write your code
	//panic("sget() is not implemented yet...!!");
	int size = sys_getSizeOfSharedObject(ownerEnvID,sharedVarName);
	if(size <= 0)
	{
		return NULL;
	}

	void* ay7aga = ROUNDDOWN(malloc((ROUNDUP(size,PAGE_SIZE))),PAGE_SIZE);

		if(ay7aga == NULL){
			return NULL;
		}
			int choice2 = sys_getSharedObject(ownerEnvID,sharedVarName,ay7aga);
			if(choice2 > 0)
			{
			 return ay7aga;
			}

			return NULL;
}


//==================================================================================//
//============================== BONUS FUNCTIONS ===================================//
//==================================================================================//

//=================================
// FREE SHARED VARIABLE:
//=================================
//	This function frees the shared variable at the given virtual_address
//	To do this, we need to switch to the kernel, free the pages AND "EMPTY" PAGE TABLES
//	from main memory then switch back to the user again.
//
//	use sys_freeSharedObject(...); which switches to the kernel mode,
//	calls freeSharedObject(...) in "shared_memory_manager.c", then switch back to the user mode here
//	the freeSharedObject() function is empty, make sure to implement it.

void sfree(void* virtual_address)
{
	  // TODO: [PROJECT'24.MS2 - BONUS#4] [4] SHARED MEMORY [USER SIDE] - sfree()
	  //  Write your code here, remove the panic and write your code
	  // panic("sfree() is not implemented yet...!!");
       int32 id = sys_get_frame(virtual_address);
       free(virtual_address);
       sys_freeSharedObject(id, virtual_address);
}



//=================================
// REALLOC USER SPACE:
//=================================
//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to malloc().
//	A call with new_size = zero is equivalent to free().

//  Hint: you may need to use the sys_move_user_mem(...)
//		which switches to the kernel mode, calls move_user_mem(...)
//		in "kern/mem/chunk_operations.c", then switch back to the user mode here
//	the move_user_mem() function is empty, make sure to implement it.
void *realloc(void *virtual_address, uint32 new_size)
{
	//[PROJECT]
	// Write your code here, remove the panic and write your code
	panic("realloc() is not implemented yet...!!");
	return NULL;
}


//==================================================================================//
//========================== MODIFICATION FUNCTIONS ================================//
//==================================================================================//

void expand(uint32 newSize)
{
	panic("Not Implemented");
}
void shrink(uint32 newSize)
{
	panic("Not Implemented");
}
void freeHeap(void* virtual_address)
{
	panic("Not Implemented");
}
