#include "kheap.h"

#include <inc/memlayout.h>
#include <inc/dynamic_allocator.h>
#include "memory_manager.h"

//Initialize the dynamic allocator of kernel heap with the given start address, size & limit
//All pages in the given range should be allocated
//Remember: call the initialize_dynamic_allocator(..) to complete the initialization
//Return:
//	On success: 0
//	Otherwise (if no memory OR initial size exceed the given limit): PANIC
struct spinlock kmalloc_spin_lock;
bool bool_kmalloc_spin_lock=1;


int initialize_kheap_dynamic_allocator(uint32 daStart, uint32 initSizeToAllocate, uint32 daLimit)
{
	//TODO: [PROJECT'24.MS2 - #01] [1] KERNEL HEAP - initialize_kheap_dynamic_allocator
	// Write your code here, remove the panic and write your code
	//panic("initialize_kheap_dynamic_allocator() is not implemented yet...!!");

	Jo_start = daStart;
	Jo_hard_limit = daLimit;
	Jo_break = Jo_start + initSizeToAllocate;

	if(Jo_break > Jo_hard_limit)
	{
		return E_NO_PAGE_FILE_SPACE;
	}
	uint32 Jo_va = Jo_start;
	while(Jo_va < Jo_break)
	{
		struct FrameInfo *Jo_frame;
		int Jo_allocated_frame = allocate_frame(&Jo_frame);
		if(Jo_allocated_frame != E_NO_PAGE_FILE_SPACE)
		{
			map_frame(ptr_page_directory,Jo_frame,Jo_va,PERM_WRITEABLE|PERM_PRESENT);
			Jo_frame->virtual_address = Jo_va;
		}
		Jo_va+=PAGE_SIZE;
	}


	initialize_dynamic_allocator(Jo_start,initSizeToAllocate);
	return 0;
}


void* sbrk(int numOfPages)
{
	/* numOfPages > 0: move the segment break of the kernel to increase the size of its heap by the given numOfPages,
	 * 				you should allocate pages and map them into the kernel virtual address space,
	 * 				and returns the address of the previous break (i.e. the beginning of newly mapped memory).
	 * numOfPages = 0: just return the current position of the segment break
	 *
	 * NOTES:
	 * 	1) Allocating additional pages for a kernel dynamic allocator will fail if the free frames are exhausted
	 * 		or the break exceed the limit of the dynamic allocator. If sbrk fails, return -1
	 */

	//MS2: COMMENT THIS LINE BEFORE START CODING==========
	//return (void*)-1 ;
	//====================================================

	//TODO: [PROJECT'24.MS2 - #02] [1] KERNEL HEAP - sbrk
	// Write your code here, remove the panic and write your code
	//panic("sbrk() is not implemented yet...!!");

	int Jo_pages = numOfPages * PAGE_SIZE;
	int Jo_current_break = Jo_break;

	if(Jo_pages == 0){return (void*)(Jo_break);}

	if(Jo_pages > 0)
	{
		int Jo_NewBreak = Jo_pages + Jo_break;
		if(Jo_NewBreak > Jo_hard_limit)
		{
			return(void*)-1;
		}
		else
		{
			uint32 Jo_iterator = Jo_break;
			while(Jo_iterator < Jo_NewBreak)
			{
				struct FrameInfo *Jo_frame;
				int Jo_allocated_frame = allocate_frame(&Jo_frame);
				if(Jo_allocated_frame != E_NO_PAGE_FILE_SPACE)
				{
					map_frame(ptr_page_directory, Jo_frame, Jo_iterator, PERM_PRESENT|PERM_WRITEABLE);
					Jo_frame->virtual_address = Jo_iterator;
				}
				else
				{
					panic("No Free frames..!!");
				}
				Jo_iterator+=PAGE_SIZE;
			}

			Jo_break = Jo_NewBreak;
			return (void*)(Jo_current_break);
		}
	}
	return(void*)-1;

}

//TODO: [PROJECT'24.MS2 - BONUS#2] [1] KERNEL HEAP - Fast Page Allocator

void* kmalloc(unsigned int size)
{
	//TODO: [PROJECT'24.MS2 - #03] [1] KERNEL HEAP - kmalloc
	if(bool_kmalloc_spin_lock)
	{
		init_spinlock(&kmalloc_spin_lock, "kmalloc_spin_lock");
		bool_kmalloc_spin_lock=0;
	}
	uint32 *Jo_table_ptr = NULL;
	uint32 Jo_sva_saver;
	uint32 Jo_page_counter = 0;
	uint32 Jo_sva;
	uint32 Jo_No_frames = ROUNDUP(size,PAGE_SIZE) / PAGE_SIZE;
    bool lock_already_held = holding_spinlock(&kmalloc_spin_lock);
	if (!lock_already_held)
	{
		acquire_spinlock(&kmalloc_spin_lock);
	}

	if (isKHeapPlacementStrategyFIRSTFIT())
	{
		if(size <= DYN_ALLOC_MAX_BLOCK_SIZE)
		{

			void *jo_allocate = alloc_block_FF(size);
			if (!lock_already_held)
			{
				release_spinlock(&kmalloc_spin_lock);
			}
			return jo_allocate;
		}
		if (size == 0)
		{
			if (!lock_already_held)
					{
						release_spinlock(&kmalloc_spin_lock);
					}				return NULL;
		}

		uint32 Jo_vaddr = Jo_hard_limit + PAGE_SIZE ;
		while (Jo_vaddr < KERNEL_HEAP_MAX)
		{

			struct FrameInfo *Jo_page;
			Jo_page = get_frame_info(ptr_page_directory, Jo_vaddr, &Jo_table_ptr);

			if (Jo_page != NULL)
			{
				Jo_page_counter = 0;
			}

			else
			{
				Jo_page_counter++;
			}

			if(Jo_page_counter == 1)
			{
				Jo_sva = Jo_vaddr;
			}

			if(Jo_page_counter == Jo_No_frames)
			{

				break;
			}

			Jo_vaddr += PAGE_SIZE;
		 }

		if(Jo_page_counter != Jo_No_frames)
		{
			release_spinlock(&kmalloc_spin_lock);
			return NULL;
		}
		Jo_sva_saver = Jo_sva;
		int Jo_frames = 0;
		while(Jo_No_frames > Jo_frames)
		{
			struct FrameInfo *freeptr;
			int Jo_allocated_frame = allocate_frame(&freeptr);
			if(Jo_allocated_frame == E_NO_MEM)
			{
				release_spinlock(&kmalloc_spin_lock);
				return NULL;
			}

			if(Jo_allocated_frame == 0)
			{
				Jo_allocated_frame = map_frame(ptr_page_directory, freeptr, Jo_sva_saver, PERM_PRESENT |  PERM_WRITEABLE);
				freeptr->virtual_address = Jo_sva_saver;
			}

			if(Jo_allocated_frame == E_NO_MEM)
			{
				release_spinlock(&kmalloc_spin_lock);
				return NULL;
			}
			Jo_sva_saver += PAGE_SIZE;
			Jo_frames++;
		}

		struct FrameInfo* Jo_fr = get_frame_info(ptr_page_directory, Jo_sva, &Jo_table_ptr);
		Jo_fr->num_frames = Jo_No_frames;

		if (!lock_already_held)
				{
					release_spinlock(&kmalloc_spin_lock);
				}
		return (void*)Jo_sva;
	}

	if (!lock_already_held)
			{
				release_spinlock(&kmalloc_spin_lock);
			}
	return NULL;
}


void kfree(void* virtual_address)
{
	//TODO: [PROJECT'24.MS2 - #04] [1] KERNEL HEAP - kfree
	// Write your code here, remove the panic and write your code
	//panic("kfree() is not implemented yet...!!");

	//you need to get the size of the given allocation using its address
	//refer to the project presentation and documentation for details
	if(bool_kmalloc_spin_lock)
	{
		init_spinlock(&kmalloc_spin_lock, "kmalloc_spin_lock");
		bool_kmalloc_spin_lock=0;
	}
	uint32 *Jo_page_table_ptr;
	uint32 Jo_va = (uint32) virtual_address;
    bool lock_already_held = holding_spinlock(&kmalloc_spin_lock);
	if (!lock_already_held)
	{
		acquire_spinlock(&kmalloc_spin_lock);
	}
	struct FrameInfo* Jo_frame1 = get_frame_info(ptr_page_directory, Jo_va, &Jo_page_table_ptr);
	uint32 Jo_num_offrames = Jo_frame1->num_frames;

	if(Jo_va < KERNEL_HEAP_START || Jo_va > KERNEL_HEAP_MAX)
	{
		if (!lock_already_held)
				{
					release_spinlock(&kmalloc_spin_lock);
				}
		return;
	}

	if((Jo_va >= Jo_start) && (Jo_va < Jo_break))
	{
		free_block(virtual_address);
		if (!lock_already_held)
				{
					release_spinlock(&kmalloc_spin_lock);
				}
		return;
	}

	int Jo_frames = 0;
	while(Jo_frames < Jo_num_offrames)
	{
		unmap_frame(ptr_page_directory,Jo_va);
		Jo_va += PAGE_SIZE;
		Jo_frames++;
	}

	if (!lock_already_held)
			{
				release_spinlock(&kmalloc_spin_lock);
			}
}

unsigned int kheap_physical_address(unsigned int virtual_address)
{
	//TODO: [PROJECT'24.MS2 - #05] [1] KERNEL HEAP - kheap_physical_address
	// Write your code here, remove the panic and write your code
	//panic("kheap_physical_address() is not implemented yet...!!");

	//return the physical address corresponding to given virtual_address
	//refer to the project presentation and documentation for details

	//EFFICIENT IMPLEMENTATION ~O(1) IS REQUIRED ==================
	uint32 * Jo_page_Table = NULL;
	uint32 Jo_page_table = (PTX(virtual_address));
	uint32 Jo_Offsett = (virtual_address & 0x00000FFF);
	int Jo_page = get_page_table(ptr_page_directory, virtual_address, &Jo_page_Table);
	if(Jo_page_Table == NULL)
	{
		return 0;
	}

	uint32 Jo_the_phys_address = ((Jo_page_Table[Jo_page_table] & 0xFFFFF000) | (Jo_Offsett));

	if(Jo_page_Table[Jo_page_table] == 0)
	{
		return 0;
	}

	return Jo_the_phys_address;

}

unsigned int kheap_virtual_address(unsigned int physical_address)
{
	//TODO: [PROJECT'24.MS2 - #06] [1] KERNEL HEAP - kheap_virtual_address
	// Write your code here, remove the panic and write your code
	//panic("kheap_virtual_address() is not implemented yet...!!");

	//return the virtual address corresponding to given physical_address
	//refer to the project presentation and documentation for details

	//EFFICIENT IMPLEMENTATION ~O(1) IS REQUIRED ==================
		unsigned int Jo_offset_bits = 0x00000FFF;
		unsigned int Jo_offset = (physical_address & Jo_offset_bits);

		struct FrameInfo *Jo_ptr = to_frame_info(physical_address);
		if(Jo_ptr->references != 0)
		{
			return ((Jo_ptr->virtual_address) | Jo_offset);
		}

		return 0;
}
//=================================================================================//
//============================== BONUS FUNCTION ===================================//
//=================================================================================//
// krealloc():

//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, if moved to another loc: the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to kmalloc().
//	A call with new_size = zero is equivalent to kfree().

void *krealloc(void *virtual_address, uint32 new_size)
{
	//TODO: [PROJECT'24.MS2 - BONUS#1M] [1] KERNEL HEAP - krealloc
	// Write your code here, remove the panic and write your code
	//return NULL;
	//panic("krealloc() is not implemented yet...!!");
	if(virtual_address==NULL&& new_size!=0){
		virtual_address= kmalloc(new_size);
	    return virtual_address;
	}
	else if(virtual_address!=NULL && new_size==0){
		kfree(virtual_address);
		return NULL;
	}
	else if(virtual_address==NULL && new_size==0){
		return NULL;
	}
	uint32 Jo_new_size= new_size+2*sizeof(int);

	if (isKHeapPlacementStrategyFIRSTFIT())
		{
		if(KERNEL_HEAP_START<(uint32)virtual_address && Jo_hard_limit>(uint32)virtual_address){
			if(new_size <= DYN_ALLOC_MAX_BLOCK_SIZE)
			{
			return realloc_block_FF(virtual_address,new_size);
			}
			else{
			void * JOnewVa=kmalloc(new_size);
			if(JOnewVa==NULL){
				return virtual_address;
			}
			memcpy(JOnewVa,virtual_address,get_block_size(virtual_address));
			free_block(virtual_address);
			return JOnewVa;
			}
			if(Jo_hard_limit+PAGE_SIZE<(uint32)virtual_address && KERNEL_HEAP_MAX> (uint32)virtual_address){

				if(new_size>DYN_ALLOC_MAX_BLOCK_SIZE){
			    void * JOnewVa =kmalloc(new_size);
			    if(JOnewVa==NULL){
					return virtual_address;
								}
			    uint32 *Jo_page_table_ptr;
			    uint32 Jo_va = (uint32) virtual_address;
			    struct FrameInfo* Jo_frame1 = get_frame_info(ptr_page_directory,Jo_va,&Jo_page_table_ptr);
			    uint32 Jo_num_offrames = Jo_frame1->num_frames;
			    memcpy(JOnewVa,virtual_address,Jo_num_offrames*PAGE_SIZE);
			    kfree(virtual_address);
			    return JOnewVa;

				}
				else{
					void *JOnewVa=alloc_block_FF(new_size);
					if(JOnewVa==NULL)
					{
						return virtual_address;
					}
					uint32 *Jo_page_table_ptr;
					uint32 Jo_va = (uint32) virtual_address;
					struct FrameInfo* Jo_frame1 = get_frame_info(ptr_page_directory,Jo_va,&Jo_page_table_ptr);
					uint32 Jo_num_offrames = Jo_frame1->num_frames;
					memcpy(JOnewVa,virtual_address,Jo_num_offrames*PAGE_SIZE);
					kfree(virtual_address);
					return JOnewVa;
				}
			}


		}

		}

return NULL;
}
