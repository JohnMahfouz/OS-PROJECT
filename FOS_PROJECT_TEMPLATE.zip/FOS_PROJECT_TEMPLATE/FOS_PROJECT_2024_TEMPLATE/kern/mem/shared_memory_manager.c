#include <inc/memlayout.h>
#include "shared_memory_manager.h"

#include <inc/mmu.h>
#include <inc/error.h>
#include <inc/string.h>
#include <inc/assert.h>
#include <inc/queue.h>
#include <inc/environment_definitions.h>

#include <kern/proc/user_environment.h>
#include <kern/trap/syscall.h>
#include "kheap.h"
#include "memory_manager.h"

//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//
struct Share* get_share(int32 ownerID, char* name);

//===========================
// [1] INITIALIZE SHARES:
//===========================
//Initialize the list and the corresponding lock
void sharing_init()
{
#if USE_KHEAP
	LIST_INIT(&AllShares.shares_list) ;
	init_spinlock(&AllShares.shareslock, "shares lock");
#else
	panic("not handled when KERN HEAP is disabled");
#endif
}

//==============================
// [2] Get Size of Share Object:
//==============================
int getSizeOfSharedObject(int32 ownerID, char* shareName)
{
	//[PROJECT'24.MS2] DONE
	// This function should return the size of the given shared object
	// RETURN:
	//	a) If found, return size of shared object
	//	b) Else, return E_SHARED_MEM_NOT_EXISTS
	//
	struct Share* ptr_share = get_share(ownerID, shareName);
	if (ptr_share == NULL)
		return E_SHARED_MEM_NOT_EXISTS;
	else
		return ptr_share->size;

	return 0;
}

//===========================================================


//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//
//===========================
// [1] Create frames_storage:
//===========================
// Create the frames_storage and initialize it by 0
inline struct FrameInfo** create_frames_storage(int numOfFrames)
{
	//TODO: [PROJECT'24.MS2 - #16] [4] SHARED MEMORY - create_frames_storage()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("create_frames_storage is not implemented yet");
	//Your Code is Here...
	struct FrameInfo** Jo_frame_pointers_list = (struct FrameInfo**)kmalloc((numOfFrames*sizeof(struct FrameInfo*)));
	for(int i = 0 ; i<numOfFrames;i++)
	{
		Jo_frame_pointers_list[i] = NULL;
	}
	if(Jo_frame_pointers_list == NULL)
	{
		return NULL;
	}
	return Jo_frame_pointers_list;




}

//=====================================
// [2] Alloc & Initialize Share Object:
//=====================================
//Allocates a new shared object and initialize its member
//It dynamically creates the "framesStorage"
//Return: allocatedObject (pointer to struct Share) passed by reference
struct Share* create_share(int32 ownerID, char* shareName, uint32 size, uint8 isWritable)
{
	//TODO: [PROJECT'24.MS2 - #16] [4] SHARED MEMORY - create_share()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("create_share is not implemented yet");
	//Your Code is Here...
	struct Share *jo_shared_object =(struct Share*)kmalloc(sizeof(struct Share));
	if(jo_shared_object==NULL)
	{
	    kfree((void*)jo_shared_object);
		return NULL;
	}
	strcpy(jo_shared_object->name, shareName);    //met3adela
	jo_shared_object->ownerID=ownerID;
	jo_shared_object->size=size;
	jo_shared_object->isWritable=isWritable;
	jo_shared_object->references=1;
	unsigned int va_masking = 0x7FFFFFFF;
	jo_shared_object->ID=(int32)(va_masking & (uint32)(jo_shared_object));
	jo_shared_object->framesStorage = create_frames_storage((int)(ROUNDUP(size,PAGE_SIZE)/PAGE_SIZE));
	if(jo_shared_object->framesStorage==NULL)
	{
		kfree((void*)jo_shared_object);
		return NULL;
	}


		return jo_shared_object;
}

//=============================
// [3] Search for Share Object:
//=============================
//Search for the given shared object in the "shares_list"
//Return:
//	a) if found: ptr to Share object
//	b) else: NULL
struct Share* get_share(int32 ownerID, char* name)
{
	//TODO: [PROJECT'24.MS2 - #17] [4] SHARED MEMORY - get_share()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("get_share is not implemented yet");
	//Your Code is Here...
	struct Share* jo_search =NULL;
	LIST_FOREACH(jo_search,&AllShares.shares_list)
	{
		if(jo_search->ownerID == ownerID)
		{
			if(strcmp(jo_search->name,name)==0)
			{
			return jo_search;
			}

		}
	}
	return NULL;
}


//=========================
// [4] Create Share Object:
//=========================
int createSharedObject(int32 ownerID, char* shareName, uint32 size, uint8 isWritable, void* virtual_address)
{

	//TODO: [PROJECT'24.MS2 - #19] [4] SHARED MEMORY [KERNEL SIDE] - createSharedObject()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	//panic("createSharedObject is not implemented yet");
	//Your Code is Here...
	acquire_spinlock(&AllShares.shareslock);
	struct Env* myenv = get_cpu_proc(); //The calling environment
	uint32 va =(uint32)virtual_address;
	struct Share* Exists =get_share(ownerID,shareName);
	if(Exists!=NULL)
	{
		release_spinlock(&AllShares.shareslock);
		return E_SHARED_MEM_EXISTS;
	}
	struct Share *Jo_shared_obj = create_share(ownerID,shareName,size,isWritable);

	if(Jo_shared_obj==NULL)
	{
	release_spinlock(&AllShares.shareslock);
	 return E_NO_SHARE;
	}
	uint32 Jo_No_frames=(ROUNDUP(size,PAGE_SIZE)/PAGE_SIZE);

	uint32 i=0;
	while(i<Jo_No_frames)
	{
		struct FrameInfo *freeptr;
		int Jo_allocated_frame = allocate_frame(&freeptr);
		if(Jo_allocated_frame < 0 )
		{
			release_spinlock(&AllShares.shareslock);
			return E_NO_SHARE;
		}
		if(Jo_allocated_frame == 0)
		{
			Jo_shared_obj->framesStorage[i]=(struct FrameInfo*)freeptr;
			Jo_allocated_frame = map_frame(myenv->env_page_directory,freeptr,va, PERM_USER |  PERM_WRITEABLE);
			freeptr->virtual_address = (uint32)virtual_address;
			freeptr->id=Jo_shared_obj->ID;

			if(i==0){
				uint32 *Jo_table_ptr =NULL;
				struct FrameInfo* Jo_fr = get_frame_info(myenv->env_page_directory,va,&Jo_table_ptr);
				Jo_fr->num_frames=Jo_No_frames;
			}
		}
		va+=PAGE_SIZE;
		i++;

	}
	LIST_INSERT_TAIL(&AllShares.shares_list,Jo_shared_obj);
	release_spinlock(&AllShares.shareslock);
	return Jo_shared_obj->ID;
}


//======================
// [5] Get Share Object:
//======================
int getSharedObject(int32 ownerID, char* shareName, void* virtual_address)
{
	//TODO: [PROJECT'24.MS2 - #21] [4] SHARED MEMORY [KERNEL SIDE] - getSharedObject()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
	 //panic("getSharedObject is not implemented yet");
	//Your Code is Here...
	//lw mafeesh writable hadeeh user w azod refrences
	//lw feeh writable hazod refrences bs
	//return ID of object
	acquire_spinlock(&AllShares.shareslock);
	struct Env* myenv = get_cpu_proc(); //The calling environment
	struct Share* Jo_shared_object=get_share(ownerID,shareName);
	uint32 va = (uint32)virtual_address;
	if(Jo_shared_object==NULL)
	{
		release_spinlock(&AllShares.shareslock);
		return E_SHARED_MEM_NOT_EXISTS;
	}

	int i=0;
	Jo_shared_object->references++;
	while( i < ((ROUNDUP(Jo_shared_object->size,PAGE_SIZE))/PAGE_SIZE))
	{
		if(Jo_shared_object->isWritable==0)
		{
			map_frame(myenv->env_page_directory,Jo_shared_object->framesStorage[i],va, PERM_USER|PERM_AVAILABLE|PERM_PRESENT);
		}
		else if(Jo_shared_object->isWritable==1)
		{
			map_frame(myenv->env_page_directory,Jo_shared_object->framesStorage[i],va, PERM_USER|PERM_AVAILABLE|PERM_WRITEABLE|PERM_PRESENT);
		}

	va+=PAGE_SIZE;
	i++;
	}
	release_spinlock(&AllShares.shareslock);
	return Jo_shared_object->ID;
}

//==================================================================================//
//============================== BONUS FUNCTIONS ===================================//
//==================================================================================//

//==========================
// [B1] Delete Share Object:
//==========================
//delete the given shared object from the "shares_list"
//it should free its framesStorage and the share object itself
void free_share(struct Share* ptrShare)
{
	//TODO: [PROJECT'24.MS2 - BONUS#4] [4] SHARED MEMORY [KERNEL SIDE] - free_share()
	//COMMENT THE FOLLOWING LINE BEFORE START CODING
   // panic("free_share is not implemented yet");
	//Your Code is Here...
	LIST_REMOVE(&AllShares.shares_list,ptrShare);
	kfree(ptrShare->framesStorage);
    kfree(ptrShare);



}
////========================
//// [B2] Free Share Object:
////========================
int freeSharedObject(int32 sharedObjectID, void *startVA)
{
    struct Env* myenv = get_cpu_proc();
    uint32 check = (uint32)startVA;
    acquire_spinlock(&AllShares.shareslock);
    struct Share* jo_share_object = NULL;
    LIST_FOREACH(jo_share_object, &AllShares.shares_list)
    {
        if (sharedObjectID == jo_share_object->ID)
		{
			break;
        }
    }

	if (jo_share_object != NULL)
	{
		for (uint32 i = 0; i < jo_share_object->size; i += PAGE_SIZE,check+=PAGE_SIZE) {
			uint32* ptr_page_table;
			get_page_table(myenv->env_page_directory, check, &ptr_page_table);
			unmap_frame(myenv->env_page_directory, check);
			if (ptr_page_table == NULL) {
				continue;
			}
			int marked = 0;
			for (int j = 0; j < 1024; j++) {
				uint32 Jo_perms = ptr_page_table[j];
				if ((Jo_perms & PERM_MARKED) == PERM_MARKED || (Jo_perms & PERM_PRESENT) == PERM_PRESENT) {
					marked = 1;
					break;
				}
			}
			if (marked == 0) {
				kfree(ptr_page_table);
				pd_clear_page_dir_entry(myenv->env_page_directory, (uint32) check);
			}
		}
		jo_share_object->references--;
		if (jo_share_object->references == 0) {
			free_share(jo_share_object);
		}
    }
    release_spinlock(&AllShares.shareslock);
	if (jo_share_object == NULL)
	{
        return E_SHARED_MEM_NOT_EXISTS;
	}
    return E_SHARED_MEM_EXISTS;
}
